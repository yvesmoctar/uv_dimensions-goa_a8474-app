package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.reader.DimsUsageViewReader
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimCountryTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimCountryGoaTask(private val config: Config, private val spark: SparkSession)
    extends DimCountryTask(config, spark, Gamora, None) {

  override val dimsUVCountryReader = DimsUsageViewReader(config, spark, Gamora)

}
