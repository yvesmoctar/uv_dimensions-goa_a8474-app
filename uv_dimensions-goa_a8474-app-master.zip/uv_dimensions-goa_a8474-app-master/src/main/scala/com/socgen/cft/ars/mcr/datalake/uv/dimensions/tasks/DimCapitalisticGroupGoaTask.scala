package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimCapitalisticGroupTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimCapitalisticGroupGoaTask(private val config: Config, private val spark: SparkSession)
 extends DimCapitalisticGroupTask(config, spark, Gamora, None)
