package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimCtrTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimCrtGoaTask(private val config: Config, private val spark: SparkSession)
    extends DimCtrTask(config, spark, Gamora)
