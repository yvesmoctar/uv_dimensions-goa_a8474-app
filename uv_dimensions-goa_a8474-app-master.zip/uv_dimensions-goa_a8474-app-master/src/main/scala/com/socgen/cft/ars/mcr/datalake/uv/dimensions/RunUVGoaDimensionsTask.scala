package com.socgen.cft.ars.mcr.datalake.uv.dimensions

import com.socgen.cft.ars.mcr.core.task.RunTasks

object RunUVGoaDimensionsTask extends RunTasks
