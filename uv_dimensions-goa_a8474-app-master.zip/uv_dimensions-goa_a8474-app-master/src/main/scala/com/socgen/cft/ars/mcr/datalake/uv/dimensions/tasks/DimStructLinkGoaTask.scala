package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimStructLinkTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimStructLinkGoaTask (private val config: Config, private val spark: SparkSession)
  extends DimStructLinkTask(config, spark, Gamora, None)
