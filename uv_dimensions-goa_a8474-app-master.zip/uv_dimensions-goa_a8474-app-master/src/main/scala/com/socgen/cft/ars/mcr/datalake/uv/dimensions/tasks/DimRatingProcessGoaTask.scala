package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimRatingProcessTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimRatingProcessGoaTask (private val config: Config, private val spark: SparkSession)
extends DimRatingProcessTask(config, spark, Gamora)
