package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimTypeSureteTask
import com.socgen.cft.ars.mcr.datalake.uv.raw.reader.{RawUsageViewReader, TypeSureteRawUsageViewReader}
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimTypeSureteGoaTask(private val config: Config, private val spark: SparkSession)
extends DimTypeSureteTask(config, spark, Gamora){

  override val rawUVReader: TypeSureteRawUsageViewReader = RawUsageViewReader(config, spark, Gamora)

}
