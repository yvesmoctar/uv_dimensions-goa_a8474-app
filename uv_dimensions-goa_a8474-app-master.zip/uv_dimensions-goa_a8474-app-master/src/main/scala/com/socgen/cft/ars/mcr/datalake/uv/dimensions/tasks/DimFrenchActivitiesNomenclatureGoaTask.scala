package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.reader._
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimFrenchActivitiesNomenclatureTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

case class DimFrenchActivitiesNomenclatureGoaTask(private val config: Config, private val spark: SparkSession)
  extends DimFrenchActivitiesNomenclatureTask(config, spark, Gamora, None) {

  val dimsUVReader: DimFrenchActivitiesNomenclatureReader =
    DimsUsageViewReader(config, spark, Gamora)
}
