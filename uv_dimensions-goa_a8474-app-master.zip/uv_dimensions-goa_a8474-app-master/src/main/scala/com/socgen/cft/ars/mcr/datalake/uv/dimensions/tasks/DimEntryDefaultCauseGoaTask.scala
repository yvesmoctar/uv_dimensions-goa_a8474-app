package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimEntryDefaultCauseTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimEntryDefaultCauseGoaTask (private val config: Config, private val spark: SparkSession)
  extends DimEntryDefaultCauseTask(config, spark, Gamora, None)
