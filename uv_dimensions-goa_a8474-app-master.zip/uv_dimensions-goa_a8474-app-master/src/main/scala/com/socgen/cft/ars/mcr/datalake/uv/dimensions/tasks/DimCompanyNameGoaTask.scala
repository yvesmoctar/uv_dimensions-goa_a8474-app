package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimCompanyNameTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimCompanyNameGoaTask(private val config: Config, private val spark: SparkSession)
    extends DimCompanyNameTask(config, spark, Gamora, None)
