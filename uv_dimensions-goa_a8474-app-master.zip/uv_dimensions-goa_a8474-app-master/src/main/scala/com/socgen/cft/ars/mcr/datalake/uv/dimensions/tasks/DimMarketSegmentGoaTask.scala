package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimMarketSegmentTask
import com.socgen.cft.ars.mcr.datalake.uv.raw.reader._
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimMarketSegmentGoaTask(private val config: Config, private val spark: SparkSession)
    extends DimMarketSegmentTask(config, spark, Gamora) {

  val rawUVReader: MarketSegmentRawUsageViewReader =
    RawUsageViewReader(config, spark, Gamora)
}
