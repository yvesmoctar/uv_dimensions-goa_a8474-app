package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimExitDefaultCriteriaTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimExitDefaultCriteriaGoaTask (private val config: Config, private val spark: SparkSession)
  extends DimExitDefaultCriteriaTask(config, spark, Gamora, None)
