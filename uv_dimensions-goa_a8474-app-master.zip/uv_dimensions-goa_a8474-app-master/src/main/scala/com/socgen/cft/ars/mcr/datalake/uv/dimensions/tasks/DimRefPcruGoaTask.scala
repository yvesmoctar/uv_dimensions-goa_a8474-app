package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.reader.DimsUsageViewReader
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimRefPcruTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimRefPcruGoaTask(private val config: Config, private val spark: SparkSession)
    extends DimRefPcruTask(config, spark, Gamora, None) {
  override val dimRefPcruReader = DimsUsageViewReader(config, spark, Gamora)
}
