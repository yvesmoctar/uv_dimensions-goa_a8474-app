package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimBaselPortfolioTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimBaselPortfolioGoaTask (private val config: Config, private val spark: SparkSession)
  extends DimBaselPortfolioTask(config, spark, Gamora, None)
