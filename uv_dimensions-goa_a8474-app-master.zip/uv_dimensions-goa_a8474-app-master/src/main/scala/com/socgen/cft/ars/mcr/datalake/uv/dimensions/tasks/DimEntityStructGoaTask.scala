package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.reader.DimsUsageViewReader
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimStructEntityTask
import com.socgen.cft.ars.mcr.datalake.uv.raw.reader.RawUsageViewReader
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimEntityStructGoaTask(private val config: Config, private val spark: SparkSession)
    extends DimStructEntityTask(config, spark, Gamora) {

  override val rawUVReader              = RawUsageViewReader(config, spark, Gamora)
  override val dimsUvEntityStructReader = DimsUsageViewReader(config, spark, Gamora)
}
