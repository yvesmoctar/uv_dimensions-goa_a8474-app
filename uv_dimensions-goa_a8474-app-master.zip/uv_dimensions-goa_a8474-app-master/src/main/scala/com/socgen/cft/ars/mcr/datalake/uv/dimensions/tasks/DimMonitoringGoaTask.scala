package com.socgen.cft.ars.mcr.datalake.uv.dimensions.tasks

import com.socgen.cft.ars.mcr.datalake.DatalakeDomains.Gamora
import com.socgen.cft.ars.mcr.datalake.uv.dims.tasks.DimMonitoringStructureTask
import com.typesafe.config.Config
import org.apache.spark.sql.SparkSession

final case class DimMonitoringGoaTask(private val config: Config, private val spark: SparkSession)
    extends DimMonitoringStructureTask(config, spark, Gamora, None)
